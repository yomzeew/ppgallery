<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="fontawesome-free-5.11.2-web/css/all.css"/>
<link rel="stylesheet" type="text/css" href="css/mystyle.css"/>
<link rel="stylesheet" type="text/css" href="css/gglayout.css"/>
<link rel="stylesheet" type="text/css" href="css/materialize.css"/>
<link rel="stylesheet" type="text/css" href="css/animate.min.css"/>
<title>HOME PAGE</title>
<script type="text/javascript" src="js/generatestaffid.js"></script>
</head>
<body style="background-color:#cccccc;">
<div class="topdiv">
<div style="position:fixed; margin-top:200px;margin-left:20px; z-index:999;">
<div><span style="color:#FFF;" class="fab fa-2x fa-instagram"></span></div>
<div title="facebook" style="margin-top:10px"><span style="color:#FFF;" class="fab fa-2x fa-facebook"></span></div>
<div title="Google plus" style="margin-top:10px"><span style="color:#FFF;" class="fab fa-2x fa-google-plus"></span></div>
<div title="Admin Page" style="margin-top:10px"><span style="color:#FFF;" class="fa fa-2x fa-user-circle"></span></div>
</div>
<div align="center" class="bounceIn" style="background-color:#F00; width:50px; height:50px; padding-top:10px; margin-top:50px; margin-left:50px;"><img src="img/logo.png" class="img-fluid" /></div>
<div align="center" style="color:#fff; margin-top:150px;">
<h2 class="animated heartBeat">PICTURE PERFECT</h2><div style="margin-top:-30px;">VIEW GALLERY</div><br />
<span class="galleryview" style="background-color:#F00;">WEDDING</span><span class="galleryview" style="color:#000; background-color:#FF0;">BIRTHDAY</span><span style="background-color:#0F0;color:#000000;" class="galleryview">MODEL</span><span style="background-color:#F0F; color:#000;" class="galleryview">FASHION</span><span style="background-color:#0FF; color:#000;" class="galleryview">ARCHITECTURE</span>

</div>
</div>
<div class="contain">
<div align="center" class="title">
 <span class="fa fa-2x fa-home"></span>PICTURE PERFECT<br>GALLERY
</div>
<div align="center" style="margin-top:20px;" class="row">
<div align="center" class="col-lg-3">
<h4><span class="fa fa-address-book"></span>BOOKING</h4>
<div  style="background-color:#333; height:400px; width:300px; padding:40px;">
<form>
<input style="color:#FFF" class="" placeholder="NAME" />
<input style="color:#FFF" class="" placeholder="PHONE NUMBER" />
<input style="color:#FFF" class="" placeholder="EMAIL" />
<input style="color:#FFF" class="" placeholder="EVENT DATE" />
<select style="" class="form-control">
<option>TYPE OF EVENT</option>
<option>WEDDING</option>
<option>BIRTHDAY</option>
<option>FASHION</option>
<option>MODEL</option>
<option>OTHER</option>
</select>
<div align="right" style="margin-top:20px"><input type="submit" style="border:none; color:#fff; background-color:#ff0000; padding:10px;" /></div>
</form>
</div>
<div style="background-color:#ff0000;width:300px;height:5px;"></div>
</div>
<div align="center" class="col-lg-3">
<span style="color:#ff0000;" class="fa fa-6x fa-map-signs"></span>
   <div align="center" style="background-color:#333; height:400px; width:300px; margin-top:-20px; padding-top:50px;">
       <span style="line-height:20px; font-size:12px; color:#FFF;"><span style="font-size:14px;">HEAD OFFICE:</span><br /> 
NO 131 OKE IJEBU <br />
BESIDE PLAZA JUNCTION<br />
AKURE, ONDO STATE<br /><br /></span>
<span style="line-height:20px; font-size:12px; color:#FFF;"><span style="font-size:14px;">BRANCH OFFICE</span><br />
NO 7 ILORO STREET <br />
STADIUM  ROAD <br />
AKURE, ONDO STATE</span>
      </div> 
      <div style="background-color:#ff0000;width:300px;height:5px;"></div>
    </div>
    <div align="center" class="col-lg-3">
<h4><span class="fa  fa-user"></span>ABOUT US</h4>
   <div align="center" style="background-color:#333; height:400px; width:300px; padding:50px;">
       <span style="line-height:20px; font-size:14px; color:#FFF;">
Our goal is create a studio that provides modern equipment and facilities to individuals familes, businesses, photographers, and videographers in Nigeria, There is no limit to the creativity and result achieved at Picture Perfect Studio Nigeria.<br /><br /></span>
<span style="line-height:20px; font-size:12px; color:#FFF;">
Our photography services are top notch; enjoying moment and creating memories that forever.</span>
      </div> 
      <div style="background-color:#ff0000;width:300px;height:5px;"></div>
    </div>
</div>
<div style="height:25px; background-color:#333333; color:#ff0000; margin-top:250px;"> NEXT<span class="fa fa-arrow-right"></span></div>
</div>
</body> 